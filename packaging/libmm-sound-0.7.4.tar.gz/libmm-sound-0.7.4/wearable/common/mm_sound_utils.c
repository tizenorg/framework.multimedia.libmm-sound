/*
 * libmm-sound
 *
 * Copyright (c) 2000 - 2011 Samsung Electronics Co., Ltd. All rights reserved.
 *
 * Contact: Seungbae Shin <seungbae.shin@samsung.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>

#include <vconf.h>
#include <vconf-keys.h>
#include <avsys-audio.h>
#include <mm_types.h>
#include <mm_error.h>
#include <mm_debug.h>
#include "../include/mm_sound_private.h"
#include "../include/mm_sound.h"
#include "../include/mm_sound_common.h"
#include "../include/mm_sound_utils.h"

/* FIXME: remove following definition after added to vconf header */
#define VCONFKEY_SOUND_CAPTURE_STATUS "memory/Sound/SoundCaptureStatus"

static mm_sound_route g_valid_route[] = {
		MM_SOUND_ROUTE_OUT_SPEAKER, MM_SOUND_ROUTE_OUT_RECEIVER, MM_SOUND_ROUTE_OUT_WIRED_ACCESSORY, MM_SOUND_ROUTE_OUT_BLUETOOTH,
		MM_SOUND_ROUTE_OUT_DOCK, MM_SOUND_ROUTE_OUT_HDMI, MM_SOUND_ROUTE_OUT_MIRRORING, MM_SOUND_ROUTE_OUT_USB_AUDIO, MM_SOUND_ROUTE_OUT_MULTIMEDIA_DOCK,
		MM_SOUND_ROUTE_IN_MIC, MM_SOUND_ROUTE_IN_WIRED_ACCESSORY, MM_SOUND_ROUTE_IN_MIC_OUT_RECEIVER,
		MM_SOUND_ROUTE_IN_MIC_OUT_SPEAKER, MM_SOUND_ROUTE_IN_MIC_OUT_HEADPHONE,
		MM_SOUND_ROUTE_INOUT_HEADSET, MM_SOUND_ROUTE_INOUT_BLUETOOTH
};

#define MM_SOUND_DEFAULT_VOLUME_SYSTEM			9
#define MM_SOUND_DEFAULT_VOLUME_NOTIFICATION	11
#define MM_SOUND_DEFAULT_VOLUME_ALARAM			7
#define MM_SOUND_DEFAULT_VOLUME_RINGTONE		11
#define MM_SOUND_DEFAULT_VOLUME_MEDIA			7
#define MM_SOUND_DEFAULT_VOLUME_CALL			4
#define MM_SOUND_DEFAULT_VOLUME_VOIP			4
#define MM_SOUND_DEFAULT_VOLUME_SVOICE			7
#define MM_SOUND_DEFAULT_VOLUME_ANDROID			0
#define MM_SOUND_DEFAULT_VOLUME_JAVA			11
#if 0
static int g_default_volume[VOLUME_TYPE_MAX] = {
	MM_SOUND_DEFAULT_VOLUME_SYSTEM,
	MM_SOUND_DEFAULT_VOLUME_NOTIFICATION,
	MM_SOUND_DEFAULT_VOLUME_ALARAM,
	MM_SOUND_DEFAULT_VOLUME_RINGTONE,
	MM_SOUND_DEFAULT_VOLUME_MEDIA,
	MM_SOUND_DEFAULT_VOLUME_CALL,
	MM_SOUND_DEFAULT_VOLUME_VOIP,
	MM_SOUND_DEFAULT_VOLUME_SVOICE,
	MM_SOUND_DEFAULT_VOLUME_ANDROID,
	MM_SOUND_DEFAULT_VOLUME_JAVA,
};
#endif
static char *g_volume_vconf[VOLUME_TYPE_MAX] = {
	VCONF_KEY_VOLUME_TYPE_SYSTEM,		/* VOLUME_TYPE_SYSTEM */
	VCONF_KEY_VOLUME_TYPE_NOTIFICATION,	/* VOLUME_TYPE_NOTIFICATION */
	VCONF_KEY_VOLUME_TYPE_ALARM,		/* VOLUME_TYPE_ALARM */
	VCONF_KEY_VOLUME_TYPE_RINGTONE,		/* VOLUME_TYPE_RINGTONE */
	VCONF_KEY_VOLUME_TYPE_MEDIA,		/* VOLUME_TYPE_MEDIA */
	VCONF_KEY_VOLUME_TYPE_CALL,			/* VOLUME_TYPE_CALL */
	VCONF_KEY_VOLUME_TYPE_VOIP,			/* VOLUME_TYPE_VOIP */
	VCONF_KEY_VOLUME_TYPE_SVOICE,		/* VOLUME_TYPE_SVOICE */
	VCONF_KEY_VOLUME_TYPE_ANDROID,		/* VOLUME_TYPE_FIXED */
	VCONF_KEY_VOLUME_TYPE_JAVA			/* VOLUME_TYPE_EXT_JAVA */
};
static char *g_volume_str[VOLUME_TYPE_MAX] = {
	"SYSTEM",
	"NOTIFICATION",
	"ALARM",
	"RINGTONE",
	"MEDIA",
	"CALL",
	"VOIP",
	"SVOICE",
	"FIXED",
	"JAVA",
};

#ifdef TIZEN_MICRO
static int __convert_vol_type_into_idx_for_safety_volume (volume_type_t type)
{
	int result = 0;
	switch (type) {
	/* only supported below types for safety volume popup */
	case VOLUME_TYPE_NOTIFICATION:
		result = 0x0001;
		break;
	case VOLUME_TYPE_RINGTONE:
		result = 0x0002;
		break;
	case VOLUME_TYPE_CALL:
		result = 0x0004;
		break;
	default:
		break;
	}
	return result;
}
#endif

EXPORT_API
int _mm_sound_get_valid_route_list(mm_sound_route **route_list)
{
	*route_list = g_valid_route;

	return (int)(sizeof(g_valid_route) / sizeof(mm_sound_route));
}

EXPORT_API
bool _mm_sound_is_route_valid(mm_sound_route route)
{
	mm_sound_route *route_list = 0;
	int route_index = 0;
	int route_list_count = 0;

	route_list_count = _mm_sound_get_valid_route_list(&route_list);
	for (route_index = 0; route_index < route_list_count; route_index++) {
		if (route_list[route_index] == route)
			return 1;
	}

	return 0;
}

EXPORT_API
void _mm_sound_get_devices_from_route(mm_sound_route route, mm_sound_device_in *device_in, mm_sound_device_out *device_out)
{
	if (device_in && device_out) {
		*device_in = route & 0x00FF;
		*device_out = route & 0xFFF00;
	}
}

EXPORT_API
bool _mm_sound_check_hibernation (const char *path)
{
	int fd = -1;
	if (path == NULL) {
		debug_error ("Path is null\n");
		return false;
	}

	fd = open (path, O_RDONLY | O_CREAT, 0644);
	if (fd != -1) {
		debug_log ("Open [%s] success!!\n", path);
	} else {
		debug_error ("Can't create [%s] with errno [%d]\n", path, errno);
		return false;
	}

	close (fd);
	return true;
}

#ifdef SEPARATE_EARPHONE_VOLUME
static inline bool __mm_sound_is_unified_volume_type(volume_type_t type)
{
	if ((type == VOLUME_TYPE_RINGTONE) || (type == VOLUME_TYPE_NOTIFICATION) || (type == VOLUME_TYPE_ALARM))
		return 1;
	else
		return 0;
}
#endif

EXPORT_API
int _mm_sound_volume_add_callback(volume_type_t type, void *func, void* user_data)
{
	if (vconf_notify_key_changed(g_volume_vconf[type], func, user_data)) {
		debug_error ("vconf_notify_key_changed failed..\n");
		return MM_ERROR_SOUND_INTERNAL;
	}

	return MM_ERROR_NONE;
}

EXPORT_API
int _mm_sound_volume_remove_callback(volume_type_t type, void *func)
{
	if (vconf_ignore_key_changed(g_volume_vconf[type], func)) {
		debug_error ("vconf_ignore_key_changed failed..\n");
		return MM_ERROR_SOUND_INTERNAL;
	}

	return MM_ERROR_NONE;
}

EXPORT_API
int _mm_sound_muteall_add_callback(void *func)
{
	if (vconf_notify_key_changed(VCONF_KEY_MUTE_ALL, func, NULL)) {
		debug_error ("vconf_notify_key_changed failed..\n");
		return MM_ERROR_SOUND_INTERNAL;
	}

	return MM_ERROR_NONE;
}

EXPORT_API
int _mm_sound_muteall_remove_callback(void *func)
{
	if (vconf_ignore_key_changed(VCONF_KEY_MUTE_ALL, func)) {
		debug_error ("vconf_ignore_key_changed failed..\n");
		return MM_ERROR_SOUND_INTERNAL;
	}

	return MM_ERROR_NONE;
}

#ifdef SEPARATE_EARPHONE_VOLUME
EXPORT_API
mm_sound_volume_device_out_t _mm_sound_get_volume_device_index(mm_sound_device_out device_out)
{
	/* convert device_out enum for PA */
	switch (device_out) {
		case MM_SOUND_DEVICE_OUT_SPEAKER:
			return MM_SOUND_VOLUME_DEVICE_OUT_SPEAKER;
		case MM_SOUND_DEVICE_OUT_RECEIVER:
			return MM_SOUND_VOLUME_DEVICE_OUT_RECEIVER;
		case MM_SOUND_DEVICE_OUT_WIRED_ACCESSORY:
			return MM_SOUND_VOLUME_DEVICE_OUT_WIRED_ACCESSORY;
		case MM_SOUND_DEVICE_OUT_BT_SCO:
			return MM_SOUND_VOLUME_DEVICE_OUT_BT_SCO;
		case MM_SOUND_DEVICE_OUT_BT_A2DP:
			return MM_SOUND_VOLUME_DEVICE_OUT_BT_A2DP;
		case MM_SOUND_DEVICE_OUT_DOCK:
			return MM_SOUND_VOLUME_DEVICE_OUT_DOCK;
		case MM_SOUND_DEVICE_OUT_HDMI:
			return MM_SOUND_VOLUME_DEVICE_OUT_HDMI;
		case MM_SOUND_DEVICE_OUT_MIRRORING:
			return MM_SOUND_VOLUME_DEVICE_OUT_MIRRORING;
		case MM_SOUND_DEVICE_OUT_USB_AUDIO:
			return MM_SOUND_VOLUME_DEVICE_OUT_USB_AUDIO;
		case MM_SOUND_DEVICE_OUT_MULTIMEDIA_DOCK:
			return MM_SOUND_VOLUME_DEVICE_OUT_MULTIMEDIA_DOCK;
		case MM_SOUND_DEVICE_OUT_NONE:
		default:
			debug_error("inavlid device_out:%x", device_out);
			return MM_SOUND_DEVICE_OUT_SPEAKER;
	}
}

EXPORT_API
int _mm_sound_volume_get_value_by_active_device(char *buf, mm_sound_device_out device_out, unsigned int *value)
{
	char val[3];
	mm_sound_volume_device_out_t i;

	i = _mm_sound_get_volume_device_index(device_out);

	memset(val, 0, sizeof(val));
	val[0] = buf[i*2];
	val[1] = buf[i*2+1];

	*value = atoi(val);

	return MM_ERROR_NONE;
}

EXPORT_API
int _mm_sound_volume_set_value_by_active_device(char *buf, mm_sound_device_out device_out, int value)
{
	char val[3];
	mm_sound_volume_device_out_t i;

	i = _mm_sound_get_volume_device_index(device_out);

	memset(val, 0, sizeof(val));
	sprintf(val, "%02d", value);

	buf[i*2] = val[0];
	buf[i*2+1] = val[1];

	return MM_ERROR_NONE;
}
#endif

EXPORT_API
int _mm_sound_volume_get_value_by_type(volume_type_t type, unsigned int *value)
{
	int ret = MM_ERROR_NONE;

#ifdef SEPARATE_EARPHONE_VOLUME
	char *str = NULL;
	mm_sound_device_in device_in = MM_SOUND_DEVICE_IN_NONE;
	mm_sound_device_out device_out = MM_SOUND_DEVICE_OUT_NONE;

	if(MM_ERROR_NONE != mm_sound_get_active_device(&device_in, &device_out)) {
		debug_error("Can not get active device info\n");
		return MM_ERROR_SOUND_INTERNAL;
	}

	/* Get volume value string from VCONF */
	if ((str = vconf_get_str(g_volume_vconf[type])) == NULL) {
		debug_error ("vconf_get_str(%s) failed..\n", g_volume_vconf[type]);
		return MM_ERROR_SOUND_INTERNAL;
	}

	if (__mm_sound_is_unified_volume_type(type)) {
		*value = atoi(str);
	} else {
		ret = _mm_sound_volume_get_value_by_active_device(str, device_out, value);
	}

	free(str);
#else
	int vconf_value = 0;

	/* Get volume value from VCONF */
	if (vconf_get_int(g_volume_vconf[type], &vconf_value)) {
		debug_error ("vconf_get_int(%s) failed..\n", g_volume_vconf[type]);
		return MM_ERROR_SOUND_INTERNAL;
	}

	*value = vconf_value;
#endif

	if (ret == MM_ERROR_NONE)
		debug_log("volume_get_value %s %d",  g_volume_str[type], *value);

	return ret;
}

EXPORT_API
int _mm_sound_volume_set_value_by_type(volume_type_t type, unsigned int value)
{
	int ret = MM_ERROR_NONE;
#ifdef SEPARATE_EARPHONE_VOLUME
	char *old = NULL;
	char new[128];
	mm_sound_device_in device_in = MM_SOUND_DEVICE_IN_NONE;
	mm_sound_device_out device_out = MM_SOUND_DEVICE_OUT_NONE;

	if(MM_ERROR_NONE != mm_sound_get_active_device(&device_in, &device_out)) {
		debug_error("Can not get active device info\n");
		return MM_ERROR_SOUND_INTERNAL;
	}

	memset(new, 0, sizeof(new));

	if (__mm_sound_is_unified_volume_type(type)) {
		sprintf(new, "%d", value);
	} else {
		/* Get volume value string from VCONF */
		if ((old = vconf_get_str(g_volume_vconf[type])) == NULL) {
			debug_error ("vconf_get_str(%s) failed..\n", g_volume_vconf[type]);
			return MM_ERROR_SOUND_INTERNAL;
		}

		ret = _mm_sound_volume_set_value_by_active_device(old, device_out, value);
		strcpy(new, old);
		free(old);

		if (ret != MM_ERROR_NONE)
			return MM_ERROR_SOUND_INTERNAL;
	}

	/* Set volume value string from VCONF */
	if (vconf_set_str(g_volume_vconf[type], new) != 0) {
		debug_error ("vconf_set_str(%s):%s failed..\n", g_volume_vconf[type], new);
		return MM_ERROR_SOUND_INTERNAL;
	}
#else
	int vconf_value = 0;

	vconf_value = value;
	debug_log("volume_set_value %s %d",  g_volume_str[type], value);

	/* Set volume value to VCONF */
	if (vconf_set_int(g_volume_vconf[type], vconf_value)) {
		debug_error ("vconf_set_int(%s) failed..\n", g_volume_vconf[type]);
		return MM_ERROR_SOUND_INTERNAL;
	}
#endif

	return ret;
}

#if 0
EXPORT_API
int _mm_sound_volume_get_values_on_bootup(int *values)
{
	int i, vconf_value = 0;
	int earjack_connected = 0;

	_mm_sound_get_earjack_type(&earjack_connected);

	for (i = 0; i < VOLUME_TYPE_MAX; i++) {
		if (!vconf_get_int(g_volume_vconf[i], &vconf_value)) {
#ifdef SEPARATE_EARPHONE_VOLUME
		if (earjack_connected) {
			values[i] = (vconf_value >> 8) & 0x00FF;
			debug_msg("volume_get_values %s [earphone] %d(0x%04x)", g_volume_str[i], values[i], vconf_value);
		} else {
			values[i] = vconf_value & 0x00FF;
			debug_msg("volume_get_values %s [speaker] %d(0x%04x)", g_volume_str[i], values[i], vconf_value);
		}
#else
		*values[i] = vconf_value;
		debug_log("volume_get_value %s %d", g_volume_str[i], values[i]);
#endif
		} else {
			debug_error ("vconf_get_int(%s) failed..\n", g_volume_vconf[i]);
			values[i] = g_default_volume[i];
#ifdef SEPARATE_EARPHONE_VOLUME
			vconf_value = (values[i] << 8) | values[i];
#else
			vconf_value = values[i];
#endif
			if (vconf_set_int(g_volume_vconf[i], vconf_value)) {
				debug_error ("vconf_set_int(%s) failed..\n", g_volume_vconf[i]);
			}
		}
	}

	return MM_ERROR_NONE;
}
#endif

EXPORT_API
int _mm_sound_volume_set_balance(float balance)
{
	/* Set balance value to VCONF */
	if (vconf_set_dbl(VCONF_KEY_VOLUME_BALANCE, balance)) {
		debug_error ("vconf_set_dbl(%s) failed..\n", VCONF_KEY_VOLUME_BALANCE);
		return MM_ERROR_SOUND_INTERNAL;
	}

	return MM_ERROR_NONE;
}

EXPORT_API
int _mm_sound_volume_get_balance(float *balance)
{
	double balance_value = 0;

	/* Get balance value from VCONF */
	if (vconf_get_dbl(VCONF_KEY_VOLUME_BALANCE, &balance_value)) {
		debug_error ("vconf_get_int(%s) failed..\n", VCONF_KEY_VOLUME_BALANCE);
		return MM_ERROR_SOUND_INTERNAL;
	}

	*balance = balance_value;
	debug_log("balance get value [%s]=[%f]", VCONF_KEY_VOLUME_BALANCE, *balance);

	return MM_ERROR_NONE;
}

EXPORT_API
int _mm_sound_set_muteall(int muteall)
{
	/* Set muteall value to VCONF */
	if (vconf_set_int(VCONF_KEY_MUTE_ALL, muteall)) {
		debug_error ("vconf_set_int(%s) failed..\n", VCONF_KEY_MUTE_ALL);
		return MM_ERROR_SOUND_INTERNAL;
	}

	return MM_ERROR_NONE;
}

EXPORT_API
int _mm_sound_get_muteall(int *muteall)
{
	int muteall_value = 0;

	/* Get muteall value from VCONF */
	if (vconf_get_int(VCONF_KEY_MUTE_ALL, &muteall_value)) {
		debug_error ("vconf_get_int(%s) failed..\n", VCONF_KEY_MUTE_ALL);
		return MM_ERROR_SOUND_INTERNAL;
	}

	*muteall = muteall_value;
	debug_log("muteall get value [%s]=[%d]", VCONF_KEY_MUTE_ALL, *muteall);

	return MM_ERROR_NONE;
}

EXPORT_API
int _mm_sound_get_earjack_type (int *type)
{
	int earjack_status = 0;

	if (type == NULL) {
		debug_error ("invalid parameter!!!");
		return MM_ERROR_INVALID_ARGUMENT;
	}

	/* Get actual vconf value */
	vconf_get_int(VCONFKEY_SYSMAN_EARJACK, &earjack_status);
	debug_msg ("[%s] get status=[%d]\n", VCONFKEY_SYSMAN_EARJACK, earjack_status);

	*type = (earjack_status >= 0)? earjack_status : VCONFKEY_SYSMAN_EARJACK_REMOVED;

	return MM_ERROR_NONE;
}

EXPORT_API
int _mm_sound_get_dock_type (int *type)
{
	int dock_status = 0;

	if (type == NULL) {
		debug_error ("invalid parameter!!!");
		return MM_ERROR_INVALID_ARGUMENT;
	}

	/* Get actual vconf value */
	vconf_get_int(VCONFKEY_SYSMAN_CRADLE_STATUS, &dock_status);
	debug_msg ("[%s] get dock status=[%d]\n", VCONFKEY_SYSMAN_CRADLE_STATUS, dock_status);

	*type = dock_status;

	return MM_ERROR_NONE;
}

EXPORT_API
mm_sound_device_in _mm_sound_get_device_in_from_path (int path)
{
	switch (path) {
	case AVSYS_AUDIO_PATH_EX_MIC:			return MM_SOUND_DEVICE_IN_MIC;
	case AVSYS_AUDIO_PATH_EX_HEADSETMIC:	return MM_SOUND_DEVICE_IN_WIRED_ACCESSORY;
	case AVSYS_AUDIO_PATH_EX_BTMIC:			return MM_SOUND_DEVICE_IN_BT_SCO;
	default:								return MM_SOUND_DEVICE_IN_NONE;
	}
}

EXPORT_API
mm_sound_device_out _mm_sound_get_device_out_from_path (int path)
{
	switch (path) {
	case AVSYS_AUDIO_PATH_EX_SPK:			return MM_SOUND_DEVICE_OUT_SPEAKER;
	case AVSYS_AUDIO_PATH_EX_RECV:			return MM_SOUND_DEVICE_OUT_RECEIVER;
	case AVSYS_AUDIO_PATH_EX_HEADSET:		return MM_SOUND_DEVICE_OUT_WIRED_ACCESSORY;
	case AVSYS_AUDIO_PATH_EX_BTHEADSET:		return MM_SOUND_DEVICE_OUT_BT_SCO;
	case AVSYS_AUDIO_PATH_EX_A2DP:			return MM_SOUND_DEVICE_OUT_BT_A2DP;
	case AVSYS_AUDIO_PATH_EX_HDMI:			return MM_SOUND_DEVICE_OUT_HDMI;
	case AVSYS_AUDIO_PATH_EX_DOCK:			return MM_SOUND_DEVICE_OUT_DOCK;
	case AVSYS_AUDIO_PATH_EX_USBAUDIO:		return MM_SOUND_DEVICE_OUT_USB_AUDIO;
	case AVSYS_AUDIO_PATH_EX_WFD:			return MM_SOUND_DEVICE_OUT_MIRRORING;
	default:								return MM_SOUND_DEVICE_OUT_NONE;
	}
}

EXPORT_API
bool _mm_sound_is_recording (void)
{
	int capture_status = 0;

	/* Check whether audio is recording */
	vconf_get_int(VCONFKEY_SOUND_CAPTURE_STATUS, &capture_status);
	debug_log ("[%s] capture status=%d", VCONFKEY_SOUND_CAPTURE_STATUS, capture_status);

	return capture_status;
}

EXPORT_API
bool _mm_sound_is_mute_policy (void)
{
	int setting_sound_status = true;

	/* If sound is mute mode, force ringtone/notification path to headset */
	vconf_get_bool(VCONFKEY_SETAPPL_SOUND_STATUS_BOOL, &setting_sound_status);
	debug_log ("[%s] setting_sound_status=%d\n", VCONFKEY_SETAPPL_SOUND_STATUS_BOOL, setting_sound_status);

	return !setting_sound_status;
}
